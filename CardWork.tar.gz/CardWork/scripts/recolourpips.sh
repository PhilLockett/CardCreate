#!/bin/sh

# Recolour pips.

# A POSIX variable
OPTIND=1         # Reset in case getopts has been used previously in the shell.

# Initialize our own variables:
red='rgb(212, 0, 0)'
black='rgb(0, 0, 0)'

fuzz=4
output='new'

while getopts "r:k:f:o:" opt; do
    case "$opt" in
    r)  red=$OPTARG
        ;;
    k)  black=$OPTARG
        ;;
    f)  fuzz=$OPTARG
        ;;
    o)  output="../$OPTARG"
        ;;
    esac
done

shift $((OPTIND-1))

[ "$1" = "--" ] && shift

mkdir -p $output
for pip in 'C' 'D' 'H' 'S' 'CS' 'DS' 'HS' 'SS'
do
        file=$pip.png
        if [ -e "$file" ]
        then
            convert $file -fuzz $fuzz% \
                -fill "$red" -opaque 'rgb(212, 0, 0)' \
                -fill "$black" -opaque 'rgb(0, 0, 0)' \
                $output/$file
        fi
done

echo "red=$red, black=$black, Leftovers: $@"

