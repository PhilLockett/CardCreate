#!/bin/sh

# Recolour faces.

# A POSIX variable
OPTIND=1         # Reset in case getopts has been used previously in the shell.

# Initialize our own variables:
red='rgb(212, 0, 0)'
yellow='rgb(226, 207, 0)'
blue='rgb(19, 31, 103)'
black='rgb(0, 0, 0)'
white='rgb(255, 255, 255)'

fuzz=4
output='new'

while getopts "r:y:b:k:w:f:o:" opt; do
    case "$opt" in
    r)  red=$OPTARG
        ;;
    y)  yellow=$OPTARG
        ;;
    b)  blue=$OPTARG
        ;;
    k)  black=$OPTARG
        ;;
    w)  white=$OPTARG
        ;;
    f)  fuzz=$OPTARG
        ;;
    o)  output="../$OPTARG"
        ;;
    esac
done

shift $((OPTIND-1))

[ "$1" = "--" ] && shift

mkdir -p $output
for suit in 'C' 'D' 'H' 'S'
do
    for card in '2' '3' '4' '5' '6' '7' '8' '9' '10' 'A' 'J' 'K' 'Q' 'S' ''
    do
        file=$suit$card.png
        if [ -e "$file" ]
        then
            convert $file -fuzz $fuzz% \
                -fill "$red" -opaque 'rgb(212, 0, 0)' \
                -fill "$yellow" -opaque 'rgb(226, 207, 0)' \
                -fill "$blue" -opaque 'rgb(19, 31, 103)' \
                -fill "$black" -opaque 'rgb(0, 0, 0)' \
                -fill "$white" -opaque 'rgb(255, 255, 255)' \
                $output/$file
        fi
    done
done

echo "red=$red, yellow=$yellow, blue=$blue, black=$black, white=$white, Leftovers: $@"

