#!/bin/sh

# Set up initial cardgen environment.

cd faces/1/
cp ../../pips/1/S.png SA.png

cd ..
mkdir 2
cd 2/
cp ../../pips/2/S.png SA.png
cp ../1/CJ.png .
cp ../1/CK.png .
cp ../1/CQ.png .
cp ../1/DJ.png .
cp ../1/DK.png .
cp ../1/DQ.png .
cp ../1/HJ.png .
cp ../1/HK.png .
cp ../1/HQ.png .
cp ../1/SJ.png .
cp ../1/SK.png .
cp ../1/SQ.png .

cd ../../indices/

mkdir 1

cd 3/

for card in '2' '3' '4' '5' '6' '7' '8' '9' '10' 'A' 'J' 'K' 'Q' 'S' ''
do
	# Black indices.
	file=S$card.png
	if [ -e "$file" ]
	then
		cp $file ../1/C$card.png
	fi

	# Red indices.
	file=H$card.png
	if [ -e "$file" ]
	then
		cp $file ../1/D$card.png
		cp $file ../2/D$card.png
	fi
done

cd ../../pips/2/
cp ../1/D.png .
cp ../1/DS.png .
cp ../1/H.png .
cp ../1/HS.png .

cd ../../pips/3/
cp ../1/H.png .
cp ../1/S.png .
