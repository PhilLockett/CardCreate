#!/bin/sh

# A POSIX variable
OPTIND=1         # Reset in case getopts has been used previously in the shell.

# Initialize our own variables:
red='rgb(212, 0, 0)'
black='rgb(0, 0, 0)'
font='Times-New-Roman'
output='new'

while getopts "r:k:f:o:" opt; do
    case "$opt" in
    r)  red=$OPTARG
        ;;
    k)  black=$OPTARG
        ;;
    f)  font=$OPTARG; output=$font
        ;;
    o)  output=$OPTARG
        ;;
    esac
done

shift $((OPTIND-1))

[ "$1" = "--" ] && shift

mkdir -p indices
mkdir -p indices/$output
for suit in 'C' 'D'
do
    case $suit in
        "S"|"C") colour=$black;;
        "D"|"H") colour=$red;;
    esac

    for card in "2" "3" "4" "5" "6" "7" "8" "9" "10" "A" "J" "K" "Q"
    do
        convert -background none -fill "$colour" -font $font -size x350 -kerning -40 label:$card -trim +repage indices/$output/$suit$card.png
    done
done
